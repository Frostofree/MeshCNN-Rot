for n in {aa,ss} ;
    for m in {1..3} ;
        do mkdir -p $n/$m ;
    done
done